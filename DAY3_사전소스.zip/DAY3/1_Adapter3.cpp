#include <iostream>
#include <list>
#include <vector>
#include <deque>
using namespace std;

// STL �� Adapter


int main()
{
	stack<int> s;
	s.push(10);
}
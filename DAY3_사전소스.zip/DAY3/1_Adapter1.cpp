#include <iostream>
#include <string>
#include <vector>
using namespace std;

// �Ʒ� Ŭ������ �̹� �־��ٰ� ������ ���ô�.

class TextView
{
	string data;
public:
	TextView(string s) : data(s) {}

	void Show() { cout << data << endl; }
};

class Shape
{
public:
	virtual void Draw() = 0;
	virtual ~Shape() {}
};


class Rect : public Shape
{
public:
	void Draw() override { cout << "Draw Rect" << endl; }
};
class Circle : public Shape
{
public:
	void Draw() override { cout << "Draw Circle" << endl; }
};

int main()
{
	vector<Shape*> v;
}








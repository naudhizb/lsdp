//1_�߻�Ŭ����2.cpp
#include <iostream>
using namespace std;


class Camera
{
public:	void Take() { cout << "Take Picture" << endl; }
};

class People
{
public:	
	void UseCamera(Camera* p) { p->Take(); }
};

int main()
{
	People p;
	Camera c;
	p.UseCamera(&c);
}






//������1.cpp - 3page

class Base
{
public:
	Base()     {} 
	Base(int a){} 
	~Base()    {} 
};
class Derived : public Base
{
public:
						
	Derived() {}       
	Derived(int a) {}  
	~Derived() {}      
};
int main()
{
	Derived d(1);
}
// upcasting1.cpp
class Animal
{
public:
	int age;
};
class Dog : public Animal
{
public:
	int color;
};
int main()
{
	Dog d;
	Dog*    p1 = &d;
	Animal* p2 = &d; // ??

}











